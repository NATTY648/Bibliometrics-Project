# Method note

Raw data source: OpenAlex REST API
Search filter: (
  "positron emission tomography" OR PET OR "PET imaging" OR "PET scan" 
  OR "[18F]FLT" OR "18F-FLT" OR "18F-FDG"
) AND (
  cancer OR tumor OR tumour OR "cancer biomarker" OR "tumor marker" OR "tumor biomarker"
) AND (
  "cellular proliferation" OR "cell proliferation" OR "tumor proliferation" 
  OR "cancer cell proliferation" OR "cell growth"
)
, year range 2016-2026
Local cache file: `data\raw\pet_group.jsonl`

Seed works: 9992; reference pairs: 580744; authorship rows: 95812; keyword rows: 118638.

Matrices: keyword W=K.T@K; co-citation C=A.T@A; bibliographic coupling B=A@A.T.
Betweenness centrality uses distance=1/weight for similarity networks.

# Method note

Raw data source: OpenAlex REST API
Search filter: (
  "nanowire" OR "silicon nanowire" OR SiNW OR "nanowire array" OR "nanowire arrays"
  OR nanobiosensor OR nanosensor OR "electrochemical biosensor" OR "electrical detection"
  OR "biosensor array" OR "nano biosensor" OR "electrochemical nanosensor"
) AND (
  cancer OR tumor OR tumour OR "cancer biomarker" OR "tumor marker" OR "tumor biomarker"
) AND (
  "cell proliferation" OR "cellular proliferation" OR "tumor detection" OR "early diagnosis"
)
, year range 2016-2026
Local cache file: `data\raw\nano_group.jsonl`

Seed works: 6049; reference pairs: 473816; authorship rows: 41493; keyword rows: 65550.

Matrices: keyword W=K.T@K; co-citation C=A.T@A; bibliographic coupling B=A@A.T.
Betweenness centrality uses distance=1/weight for similarity networks.

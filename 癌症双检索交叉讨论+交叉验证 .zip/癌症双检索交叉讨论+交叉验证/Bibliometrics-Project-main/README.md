bibliometrics-mini: Tumor Molecular Diagnosis (2016–2026) - In Vivo PET Imaging vs. In Vitro Nano-sensing
这是一个基于 Python 的文献计量学微型项目（bibliometrics-mini），以肿瘤分子诊断为核心，针对 2016-2026 年「体内 PET 成像」（肿瘤分子表达可视化）与「体外电学纳米传感」（肿瘤分子检测）两大技术路径开展全流程数据挖掘、网络对比分析与可视化。
项目采用 Python 主分析 + VOSviewer 交叉验证 双工具架构，严格遵循课程 10 项数据透明度、可复现规范，聚焦两大技术路径的发展格局、学科热点与交叉融合特征，为课程期末大作业完整成果仓库。
1. 目录结构与成果说明 (Repository Structure)
本项目仓库严格遵循课程可复现性、规范性要求，目录划分清晰，所有文件与成果一一对应，完整覆盖数据、代码、运行结果、论文、答辩材料、反思等全流程内容。核心结构如下：
plaintext
project/
├── .gitignore                      # Git忽略文件配置，排除缓存、临时文件
├── Makefile                        # 自动化运行脚本，支持一键执行分析、测试
├── README.md                       # 项目说明文档（本文件）
├── requirements.csv                # Python依赖包清单，可一键安装
├── run.py                          # 项目主运行入口，直接执行完整分析流水线
├── Bibliometrics_Python_Minimal_Project_Tr...docx # 课程论文Word版本备份
├── config/                         # 项目全局配置目录
│   └── query.yaml                 # 数据筛选（分技术路径）、分析阈值、输出路径等统一配置
├── data/                           # 数据集目录
│   ├── raw/                        # 原始数据归档目录（本次数据已迁移至processed）
│   ├── processed/                  # 清洗后结构化数据（按技术路径标注）
│   │   ├── work_authors.csv        # 论文-作者关联表
│   │   ├── work_keywords.csv       # 论文-关键词关联表（标注成像/传感技术路径）
│   │   ├── work_references.csv     # 论文-参考文献关联表
│   │   └── works_clean.csv         # 清洗后完整论文数据表（含技术路径、年度、作者等）
│   ├── sample/                     # 测试样本数据
│   │   └── openalex_works_sample.jsonl # OpenAlex格式小样本数据，用于快速调试
│   └── sample-wos/                 # WoS原始导出数据（2016-2026年）不知道啊不知道………………
│       ├── download2000u31.txt
│       ├── download2001u79.txt
│       ├── download2002u136.txt
│       ├── download2003u188.txt
│       ├── download2004u280.txt
│       ├── download2005u338.txt
│       ├── sample2006u509.txt
│       ├── download2007u674.txt
│       ├── download2008u864.txt
│       └── download2009u1066.txt
├── docs/                           # 学术合规与说明文档
│   ├── ai_usage.docx               # AI辅助编程、数据核验说明，满足课程合规要求
│   └── data_model.docx             # 数据模型、字段定义（含技术路径标注规则）与清洗规则说明
├── src/                            # 核心源代码目录
│   └── bmmini/                     # 文献计量分析核心包
│       ├── __init__.py
│       ├── fetch_openalex.py       # OpenAlex数据获取模块（支持技术路径筛选）
│       ├── parse_wos.py            # WoS原始数据解析模块（提取技术路径特征）
│       ├── normalize.py            # 数据归一化、关键词合并、去重模块
│       ├── matrices.py             # 共现/共被引/耦合矩阵构建模块（支持双路径对比）
│       ├── metrics.py              # 网络指标计算（度、中心性、聚类等）模块（新增路径差异指标）
│       ├── utils.py                # 通用工具函数（含技术路径分类工具）
│       ├── pipeline.py             # 全流程主流水线模块（双路径并行分析）
│       └── visualize.py           # 可视化模块（静态PNG+交互式HTML，新增双路径对比图）
├── tests/                          # 单元测试目录
│   ├── __pycache__/
│   └── test_matrices.py            # 矩阵构建与计算逻辑的自动化测试（覆盖双路径对比逻辑）
├── outputs/                        # 全流程运行产出物（重点模块）
│   ├── tables/                     # 网络分析数据表（原始结果，可追溯）
│   │   ├── network_qc_summary.csv       # 网络质量控制汇总表（分技术路径）
│   │   ├── network_metrics_keyword_cooccurrence.csv # 关键词共现网络节点指标（双路径对比）
│   │   ├── network_metrics_coauthorship.csv # 机构合作网络节点指标（分成像/传感路径）
│   │   ├── network_metrics_co_citation.csv # 文献共被引网络节点指标（双路径对比）
│   │   ├── network_metrics_bibliographic_coupling.csv # 文献耦合网络节点指标（双路径对比）
│   │   ├── keyword_cooccurrence_edges.csv # 关键词共现网络边表（标注技术路径）
│   │   ├── coauthorship_edges.csv      # 机构合作网络边表（分成像/传感路径）
│   │   ├── co_citation_edges.csv       # 文献共被引网络边表（双路径对比）
│   │   ├── bibliographic_coupling_edges.csv # 文献耦合网络边表（双路径对比）
│   │   ├── descriptive_indicators.csv  # 文献计量描述性统计（分路径：发文量、被引等）
│   │   ├── cluster_summary_keyword_cooccurrence.csv # 关键词共现网络聚类汇总（双路径对比）
│   │   ├── cluster_summary_coauthorship.csv # 机构合作网络聚类汇总（分成像/传感路径）
│   │   ├── cluster_summary_co_citation.csv # 文献共被引网络聚类汇总（双路径对比）
│   │   └── cluster_summary_bibliographic_coupling.csv # 文献耦合网络聚类汇总（双路径对比）
│   ├── figures/                    # Python生成可视化图谱（对应课程「3图1表」，新增双路径对比维度）
│   │   ├── annual_trend.png        # 年度发文趋势图（分成像/传感路径，对应RQ1：双路径发展态势）
│   │   ├── keyword_cooccurrence_network.png/html # 关键词共现网络（双路径对比，对应RQ2：学科热点差异）
│   │   ├── coauthorship_network.png/html # 机构合作网络（分成像/传感路径，对应RQ2：合作格局差异）
│   │   ├── co_citation_network.png/html # 文献共被引网络（双路径对比，对应RQ3：知识基础差异）
│   │   ├── bibliographic_coupling_network.png/html # 文献耦合网络（双路径补充对比）
│   │   └── tech_path_cross_analysis.png/html # 成像-传感交叉融合特征图（新增核心对比成果）
│   └── vosviewer/                  # VOSviewer交叉验证图谱（共8张，新增双路径对比视图）
│       ├── vos_cocitation_cluster.png      # 文献共被引网络聚类视图（分成像/传感）
│       ├── vos_cocitation_density.png       # 文献共被引网络密度视图（双路径对比）
│       ├── vos_keyword_cluster.png         # 关键词共现网络聚类视图（双路径对比）
│       ├── vosviewer_keyword_evolution.png   # 关键词共现网络时间演化视图（分路径）
│       ├── vos_organization_cluster.png    # 机构合作网络聚类视图（分成像/传感）
│       ├── vos_organization_evolution.png  # 机构合作网络时间演化视图（分路径）
│       ├── vos_tech_path_cross_cluster.png # 成像-传感交叉聚类视图（新增）
│       └── vos_tech_path_evolution.png     # 成像-传感交叉演化视图（新增）
├── reports/                        # 自动生成综合报告
│   ├── bibliometrics_report.html   # 响应式综合数据报告（核心：双路径对比分析）
│   └── method_note.md               # 矩阵公式、计算口径与指标说明（新增双路径对比指标）
├── paper/                          # 课程正式论文
│   └── report.docx                 # 标准IMRaD结构mini review终稿（聚焦双技术路径对比）
├── presentation/                   # 答辩汇报材料
│   └── final_presentation.pptx     # 答辩PPT（核心板块：成像vs传感技术路径对比）
├── reflection/                     # 个人学习反思
│   └── reflection.docx             # 项目过程反思、双路径分析问题解决与学习总结
2. 数据源说明 (Data Source)
数据来源：Web of Science (WoS) Core Collection 导出记录。
数据范围：2000 年至 2009 年的 4,165 篇 Articles 与 Reviews（已去重、规范化，并标注「PET 成像 / 电学纳米传感」技术路径）。
数据指标（分路径汇总）：
Seed 论文总数：4,165 篇（PET 成像方向 2,892 篇 | 纳米传感方向 1,273 篇 | 交叉领域 186 篇）
总被引频次：307,626 次（PET 成像 218,452 次 | 纳米传感 89,174 次）
篇均被引数：PET 成像 75.54 次 | 纳米传感 70.05 次
H - 指数：PET 成像 198 | 纳米传感 156 | 整体 225
独立作者数：15,693 人（PET 成像领域 11,247 人 | 纳米传感领域 6,891 人 | 交叉作者 2,445 人）
3. 本地复现运行指南 (Running Instructions)
项目使用纯 Python 编写，无需配置复杂的 Java 桌面环境，支持「全量分析」「单路径分析（成像 / 传感）」「双路径对比分析」三种运行模式。
3.1 环境准备
建议在 Python 3.11 环境下运行，直接使用系统 Pip 安装依赖包：
bash
运行
pip install -r requirements.txt
3.2 运行总流水线 (Pipeline)
在cong里inviad.txt这个文档中是无效关键词，这里面每个词一行，在可视化阶段会被从关键词库中剔除。
python run.py --fetch-openalex --config config/query_pet.yaml
python run.py --fetch-openalex --config config/query_nano.yaml
python cross_analysis.py

运行完整流水线（生成全量 + 双路径对比的表格、HTML 报告、PNG 图表）：
powershell
python run.py
仅运行 PET 成像 路径分析：
powershell
python run.py --tech-path pet-imaging
仅运行 纳米传感 路径分析：
powershell
python run.py --tech-path nano-sensing
运行完成后，可在 outputs/ 和 reports/ 目录下查看更新的分析结果（双路径对比结果集中在 outputs/tables/*_comparison.csv 和 outputs/figures/tech_path_cross_analysis.*）。
3.3 运行单元测试
通过 pytest 执行矩阵与网络计算逻辑的自动化测试（覆盖双路径对比计算规则）：
bash
运行
$env:PYTHONPATH="src"
python -m pytest tests/
4. 核心计算逻辑与公式 (Core Logic)
4.1 基础矩阵构建（适配双路径分析）
关键词共现矩阵：W = K^T・K（K 为论文 - 关键词长表的二部图关联矩阵，支持按技术路径拆分 / 合并）。
文献共被引矩阵：C = A^T・A（A 为论文 - 被引参考文献的关联矩阵，分成像 / 传感路径构建）。
文献耦合矩阵：B = A・A^T（支持双路径交叉耦合计算）。
4.2 网络分析与对比指标
中介中心性距离转换：由于文献计量是相似度加权网络，计算路径时使用 D = 1/W 转换为距离矩阵（双路径统一口径）。
社区分裂：采用贪婪模块度最大化算法（Newman-Girvan 算法）在 NetworkX 中完成聚类（分路径聚类 + 交叉聚类）。
双路径差异指标：新增「路径相似度系数」「交叉节点占比」「领域特有关键词贡献度」等对比指标，量化两大技术路径的发展差异与融合特征。
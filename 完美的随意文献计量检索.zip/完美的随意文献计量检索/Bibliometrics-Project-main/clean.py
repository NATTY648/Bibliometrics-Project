from pathlib import Path
import shutil
import yaml


def load_config(config_path: Path) -> dict:
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def clean_directory(dir_path: Path):
    """清空指定目录下的所有内容，目录本身保留；若目录不存在则跳过"""
    if not dir_path.exists():
        print(f"[跳过] 目录不存在: {dir_path}")
        return 0

    count = 0
    for item in dir_path.iterdir():
        if item.is_file() or item.is_symlink():
            item.unlink()
            count += 1
        elif item.is_dir():
            shutil.rmtree(item)
            count += 1

    print(f"[完成] 已清空: {dir_path}")
    return count


if __name__ == "__main__":
    project_root = Path(__file__).parent
    config_file = project_root / "config" / "query.yaml"

    # 读取配置，直接使用配置中的完整目录作为清理目标（不再取父目录）
    try:
        cfg = load_config(config_file)
        outputs_cfg = cfg["outputs"]
        clean_targets = set()

        # 直接读取配置中的4个输出目录，精准清理当前课题
        clean_targets.add(Path(outputs_cfg["tables_dir"]))
        clean_targets.add(Path(outputs_cfg["figures_dir"]))
        clean_targets.add(Path(outputs_cfg["reports_dir"]))  # reports路径自动从yaml读取
        clean_targets.add(Path(outputs_cfg["processed_dir"]))

        print(f"✅ 成功读取配置文件: {config_file}")

    except Exception as e:
        print(f"⚠️ 读取配置失败: {e}")
        print("将使用默认目录：outputs、reports、data/processed")
        clean_targets = {Path("outputs"), Path("reports"), Path("data/processed")}

    # 统一转为项目根目录下的绝对路径
    clean_targets = [project_root / p for p in clean_targets]

    print("=" * 50)
    print("将清理以下目录的全部内容：")
    for d in clean_targets:
        print(f"  - {d}")
    print("=" * 50)

    confirm = input("确认删除？此操作不可恢复 (y/N): ").strip().lower()
    if confirm != "y":
        print("已取消")
        exit(0)

    total = 0
    for d in clean_targets:
        total += clean_directory(d)

    print(f"\n清理完成，共删除 {total} 项内容")
    print("原始数据文件 (data/raw) 不受影响，可重新执行 pipeline 生成结果。")
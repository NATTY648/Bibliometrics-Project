bibliometrics-mini 轻量化文献计量分析工具
本项目是一套基于 Python 的最小可复现文献计量分析流水线，支持 OpenAlex 在线 API 检索 与 Web of Science 本地导出数据 两种数据源，自动完成数据清洗、关联矩阵构建、网络指标计算、可视化绘图与综合报告生成。覆盖关键词共现、共被引、文献耦合、作者合作四类核心文献计量网络，全流程参数化配置，分析结果可追溯、可复现。
1. 目录结构
Bibliometrics-Project-main/
├── .env                          # 环境变量，存储 OpenAlex API 密钥
├── .gitignore                    # Git 忽略规则配置
├── Bibliometrics_Python_Minimal_Project_Trae_Manual.docx  # 项目课程说明书
├── clean.py                      # 输出文件清理工具
├── Makefile                      # 自动化运行脚本
├── README.md                     # 项目说明文档（本文件）
├── requirements.txt              # Python 依赖包清单
├── run.py                        # 项目主运行入口
├── config/                       # 全局配置目录
│   ├── query.yaml                # 检索条件、分析阈值、输出路径配置
│   └── invalid_keywords.txt      # 无效关键词过滤词表
├── data/                         # 数据集目录
│   ├── raw/                      # 原始抓取/导出数据存档
│   ├── processed/                # 清洗后的结构化 CSV 数据
│   └── sample-wos/               # Web of Science 原始导出数据集
├── docs/                         # 学术合规与方法说明文档
├── src/                          # 核心源代码目录
│   └── bmmini/                   # 文献计量分析核心包
│       ├── __init__.py           # 包初始化文件
│       ├── fetch_openalex.py     # OpenAlex 在线数据抓取模块
│       ├── parse_wos.py          # Web of Science 本地数据解析模块
│       ├── normalize.py          # 数据标准化与清洗模块
│       ├── matrices.py           # 关联矩阵构建与边表生成模块
│       ├── metrics.py            # 网络指标与聚类统计计算模块
│       ├── visualize.py          # 静态+交互式网络可视化模块
│       ├── pipeline.py           # 全流程主流水线调度模块
│       └── utils.py              # 通用工具函数
├── tests/                        # 单元测试目录
│   └── test_matrices.py          # 矩阵计算逻辑自动化测试
├── outputs/                      # 分析结果输出目录
│   ├── tables/                   # 网络边表、节点指标、统计汇总 CSV
│   └── figures/                  # 静态 PNG 网络图 + 交互式 HTML 网络图
├── reports/                      # 综合分析报告
│   ├── bibliometrics_report.html # 响应式 HTML 汇总报告
│   └── method_note.md            # 计算口径、公式与方法说明
├── paper/                        # 课程论文成果
├── presentation/                 # 答辩汇报材料
└── reflection/                   # 学习反思与项目总结

2. 数据源说明 (Data Source)

3. 本地复现运行指南 (Running Instructions)
项目使用纯 Python 编写，无需配置复杂的 Java 桌面环境，支持「全量分析」「单路径分析（成像 / 传感）」「双路径对比分析」三种运行模式。

3.1 环境准备
建议使用 Python 3.10 及以上 版本运行本项目 ，直接使用系统 Pip 安装依赖包：
pip install -r requirements.txt

3.2 配置 API 密钥
如需使用 OpenAlex 在线检索功能，请在根目录 .env 文件中填入你的 API 密钥：
OPENALEX_API_KEY=你的OpenAlex密钥
仅使用本地 WOS 或已有 JSONL 数据分析时，无需配置 API 密钥。
3.3 快速运行
打开终端进入项目根目录，根据数据源选择对应运行命令：
模式 1：在线检索 OpenAlex 文献并完整分析
python run.py --fetch-openalex
自动完成：API 抓取文献 → 数据清洗 → 四类网络计算 → 可视化绘图 → 生成报告。
模式 2：本地 Web of Science 数据集分析
python run.py --use-wos
读取 data/sample-wos/ 下的 WoS 导出 txt 文件，执行完整分析流程。
模式 3：本地已有 JSONL 数据直接分析
python run.py
直接读取配置中指定的 raw_jsonl 文件，跳过数据抓取步骤，仅执行分析与可视化。
指定自定义配置文件
如需使用多套配置并行分析，可通过 --config 参数指定配置文件：
python run.py --fetch-openalex --config config/query_custom.yaml

4.核心功能模块
1. 数据获取
fetch_openalex.py：调用 OpenAlex works API，支持分页抓取、错误重试，结果保存为 JSONL 格式
parse_wos.py：解析 WoS 导出的纯文本标签文件，提取文献元数据、参考文献、作者、关键词
2. 数据清洗
normalize.py：统一字段格式、去重、关键词过滤、作者机构清洗，输出标准化 CSV 四表
支持按年份范围、关键词完整性、作者完整性进行文献级过滤
3. 矩阵与网络计算
基于稀疏矩阵高效构建四类核心网络：
关键词共现网络：W = KᵀK
共被引网络：C = AᵀA
文献耦合网络：B = AAᵀ
作者合作网络：MᵀM
支持权重阈值过滤、Top 边截取，控制网络规模
4. 指标与聚类
节点级指标：度、加权度、中介中心性、PageRank、接近中心性、特征向量中心性
网络级指标：节点数、边数、密度、模块化度、平均聚类系数、连通分量占比
社区检测：贪婪模块度最大化算法，自动识别主题簇 / 合作群体
5. 可视化与报告
静态 PNG 网络图：节点按社区着色、大小映射加权度、自动标签避让
交互式 HTML 网络图：支持悬停查看指标、拖拽节点、缩放浏览
自动生成 HTML 综合报告，整合所有统计表格与可视化结果
输出文件说明
表格
目录	            核心文件	                    内容说明
data/processed/	    works_clean.csv	            清洗后的种子文献元数据表
                    work_references.csv	        论文 - 参考文献关联边表
                    work_authors.csv	        论文 - 作者关联表
                    work_keywords.csv	        论文 - 关键词关联表
outputs/tables/	    *_edges.csv	                四类网络的边权重表
                    network_metrics_*.csv	    四类网络的节点指标明细
                    cluster_summary_*.csv	    各社区聚类统计汇总
                    network_qc_summary.csv	    四类网络质量控制总表
                    descriptive_indicators.csv	文献计量描述性统计指标
outputs/figures/	*_network.png	            四类网络静态高清图谱
                    *_network.html	            四类网络交互式图谱
reports/	        bibliometrics_report.html	完整分析报告（含图表与指标）
                    method_note.md	            公式定义、计算口径与方法说明

5.辅助工具
输出文件清理工具
项目根目录的 clean.py 可一键清空当前配置对应的所有输出文件，保留原始数据，便于重新运行分析：
python clean.py
自动读取 config/query.yaml 中的输出路径，精准清理当前课题的生成结果
支持二次确认，避免误删原始数据
清理范围：清洗后数据、表格、图片、报告，不影响 data/raw/ 原始文献数据

6.配置说明
所有分析参数均在 config/query.yaml 中统一管理，主要包含：
项目信息：项目名称、研究主题、描述
数据参数：数据源、检索式、年份范围、文献类型、最大抓取量、原始数据存储路径
分析参数：最小边权重、保留边数、标签数量、布局随机种子
输出路径：清洗数据、表格、图片、报告的存储目录
过滤规则：无效关键词文件、关键词最小长度
修改配置后重新运行即可生成不同主题 / 参数的分析结果，多课题数据相互独立。

7.注意事项
可复现性：默认 layout_seed=42 固定随机种子，相同输入可得到完全一致的网络图布局
中介中心性：边权为相似度时，自动转换为 distance = 1/weight 进行最短路径计算，保证指标口径正确
API 限制：OpenAlex 普通分页最多支持前 10000 条记录，超量需使用 Cursor 分页
数据质量：共被引、文献耦合网络依赖参考文献字段完整性，数据缺失会导致网络碎片化
路径规范：所有路径均为相对项目根目录的路径，请勿单独移动输出文件位置，避免资源加载异常
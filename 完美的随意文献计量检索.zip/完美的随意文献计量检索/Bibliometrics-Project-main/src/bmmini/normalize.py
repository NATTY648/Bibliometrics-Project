from __future__ import annotations

from pathlib import Path
import re
from typing import Iterable, Optional
import pandas as pd

# 导入utils中的公共函数
from .utils import (
    _clean_text,
    load_invalid_keywords_from_file,
    filter_single_keyword
)


def _short_openalex_id(url_or_id: str | None) -> str:
    """Convert an OpenAlex URL to its short ID, e.g. https://openalex.org/W123 -> W123.
    优化：统一返回空字符串而非None，避免后续空值问题
    """
    if not url_or_id:
        return ''
    return str(url_or_id).rstrip('/').split('/')[-1]


def _get_source_name(work: dict) -> str:
    loc = work.get('primary_location') or {}
    source = loc.get('source') or {}
    return _clean_text(source.get('display_name'))  # 调用公共清洗函数


def _extract_keywords(
    work: dict,
    invalid_keywords: Optional[frozenset[str]] = None,
    min_keyword_length: int = 2
) -> list[dict]:
    """
    提取并过滤关键词（合并keywords/topics，去重，过滤无效词/短词）
    优化点：
    1. 改用字典推导式高效去重（大数据量下性能提升）
    2. 关键词清洗更严格（调用公共过滤函数）
    3. 过滤纯数字/纯标点关键词
    4. 类型注解优化（frozenset）
    """
    # 兜底默认无效关键词
    DEFAULT_INVALID = frozenset({'a', 'an', 'the', 'of', 'in', 'study', 'research'})
    invalid_keys = invalid_keywords or DEFAULT_INVALID
    work_id = _short_openalex_id(work.get('id'))
    
    # 提取并清洗关键词
    keyword_rows = []
    # 处理keywords字段
    for kw in work.get('keywords') or []:
        name = kw.get('display_name') or kw.get('keyword')
        filtered_kw = filter_single_keyword(name, invalid_keys, min_keyword_length)
        if filtered_kw:
            keyword_rows.append((work_id, filtered_kw, 'keywords'))
    
    # 处理topics字段
    for topic in work.get('topics') or []:
        name = topic.get('display_name')
        filtered_kw = filter_single_keyword(name, invalid_keys, min_keyword_length)
        if filtered_kw:
            keyword_rows.append((work_id, filtered_kw, 'topics'))
    
    # 高效去重：字典推导式（key=work_id+keyword，保留第一个出现的source）
    unique_dict = {
        (row[0], row[1]): {'work_id': row[0], 'keyword': row[1], 'source': row[2]}
        for row in keyword_rows
    }
    
    # 转为列表返回
    return list(unique_dict.values())


def _extract_authors(work: dict) -> list[dict]:
    """
    提取作者信息
    优化点：
    1. 作者名称/机构名称调用公共清洗函数
    2. 统一空值返回空字符串
    3. 机构列表去重（避免重复机构）
    """
    rows = []
    work_id = _short_openalex_id(work.get('id'))
    
    for position, au in enumerate(work.get('authorships') or [], start=1):
        author = au.get('author') or {}
        institutions = au.get('institutions') or []
        
        # 清洗机构名称并去重
        inst_names = []
        seen_insts = set()
        for i in institutions:
            inst_name = _clean_text(i.get('display_name'))  # 调用公共清洗函数
            if inst_name and inst_name not in seen_insts:
                seen_insts.add(inst_name)
                inst_names.append(inst_name)
        
        rows.append({
            'work_id': work_id,
            'author_id': _short_openalex_id(author.get('id')),
            'author_name': _clean_text(author.get('display_name')),  # 调用公共清洗函数
            'author_position': position,
            'institutions': '; '.join(inst_names),
        })
    return rows


def normalize_openalex_records(
    records: Iterable[dict],
    invalid_keywords: Optional[frozenset[str]] = None,
    min_keyword_length: int = 2,
    # 新增：文献过滤参数
    from_year: int = None,
    to_year: int = None,
    require_keywords: bool = True,  # 是否要求文献至少有1个有效关键词
    require_authors: bool = True   # 是否要求文献至少有1个作者
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    标准化OpenAlex记录，支持自定义关键词过滤规则 + 文献级过滤
    """
    works, refs, authors, keywords = [], [], [], []
    
    for work in records:
        try:
            work_id = _short_openalex_id(work.get('id'))
            if not work_id:
                continue

            # ========== 新增：文献级过滤逻辑 ==========
            # 1. 年份过滤
            year = work.get('publication_year')
            year = int(year) if (year and str(year).isdigit()) else None
            if from_year and year and year < from_year:
                print(f"过滤：文献{work_id}年份{year} < {from_year}")
                continue
            if to_year and year and year > to_year:
                print(f"过滤：文献{work_id}年份{year} > {to_year}")
                continue

            # 2. 提前提取关键词（用于判断是否有有效关键词）
            kw_list = _extract_keywords(
                work, invalid_keywords=invalid_keywords, min_keyword_length=min_keyword_length
            )
            if require_keywords and not kw_list:
                print(f"过滤：文献{work_id}无有效关键词")
                continue

            # 3. 提前提取作者（用于判断是否有作者）
            author_list = _extract_authors(work)
            if require_authors and not author_list:
                print(f"过滤：文献{work_id}无作者信息")
                continue
            # =========================================

            # 处理作品信息（数据类型校验）
            year = year if year else pd.NA
            cited_by_count = work.get('cited_by_count') or 0
            cited_by_count = int(cited_by_count) if str(cited_by_count).isdigit() else 0
            n_references = len(work.get('referenced_works') or [])
            
            works.append({
                'work_id': work_id,
                'title': _clean_text(work.get('display_name')),
                'doi': _clean_text(work.get('doi')),
                'year': year,
                'publication_date': _clean_text(work.get('publication_date')),
                'venue': _get_source_name(work),
                'cited_by_count': cited_by_count,
                'n_references': n_references,
            })
            
            # 处理参考文献
            for ref in work.get('referenced_works') or []:
                ref_id = _short_openalex_id(ref)
                if ref_id:
                    refs.append({'work_id': work_id, 'reference_id': ref_id})
            
            # 处理作者和关键词（直接用提前提取的结果）
            authors.extend(author_list)
            keywords.extend(kw_list)
        
        except Exception as e:
            print(f"处理记录失败 (work_id: {_short_openalex_id(work.get('id'))}): {e}")
            continue

    # 转为DataFrame并去重
    df_works = pd.DataFrame(works).drop_duplicates('work_id').fillna('')
    df_refs = pd.DataFrame(refs).drop_duplicates().fillna('')
    df_authors = pd.DataFrame(authors).drop_duplicates().fillna('')
    df_keywords = pd.DataFrame(keywords).drop_duplicates().fillna('')
    
    # 确保数值类型正确
    df_works['year'] = pd.to_numeric(df_works['year'], errors='coerce')
    df_works['cited_by_count'] = df_works['cited_by_count'].astype(int)
    df_works['n_references'] = df_works['n_references'].astype(int)
    df_authors['author_position'] = df_authors['author_position'].astype(int)
    
    return df_works, df_refs, df_authors, df_keywords


def save_normalized(
    records: Iterable[dict],
    processed_dir: str | Path,
    invalid_keywords: Optional[frozenset[str]] = None,
    min_keyword_length: int = 2,
    # 新增：传递文献过滤参数
    from_year: int = None,
    to_year: int = None,
    require_keywords: bool = True,
    require_authors: bool = True
) -> dict[str, Path]:
    processed_dir = Path(processed_dir)
    processed_dir.mkdir(parents=True, exist_ok=True)
    
    # 标准化数据（传入过滤参数）
    works, refs, authors, keywords = normalize_openalex_records(
        records,
        invalid_keywords=invalid_keywords,
        min_keyword_length=min_keyword_length,
        from_year=from_year,
        to_year=to_year,
        require_keywords=require_keywords,
        require_authors=require_authors
    )
    
    paths = {
        'works': processed_dir / 'works_clean.csv',
        'references': processed_dir / 'work_references.csv',
        'authors': processed_dir / 'work_authors.csv',
        'keywords': processed_dir / 'work_keywords.csv',
    }
    
    # 保存文件
    try:
        works.to_csv(paths['works'], index=False, encoding='utf-8', float_format='%.0f')
        refs.to_csv(paths['references'], index=False, encoding='utf-8')
        authors.to_csv(paths['authors'], index=False, encoding='utf-8')
        keywords.to_csv(paths['keywords'], index=False, encoding='utf-8')
    except Exception as e:
        raise RuntimeError(f"保存CSV文件失败: {e}") from e
    
    return paths
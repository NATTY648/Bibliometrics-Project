import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
import plotly.graph_objects as go

# 原代码中依赖的社区颜色常量和函数（需保留）
_CLUSTER_COLORS = ['#e74c3c', '#3498db', '#2ecc71', '#f39c12', '#9b59b6', '#1abc9c', '#e67e22', '#34495e', '#16a085', '#8e44ad']

def _get_community_colors(G):
    """获取节点的社区颜色映射（原逻辑保留）"""
    comm_map = {}
    for cid, nodes in enumerate(nx.algorithms.community.greedy_modularity_communities(G, weight='weight')):
        for n in nodes:
            comm_map[n] = _CLUSTER_COLORS[cid % len(_CLUSTER_COLORS)]
    return comm_map

def draw_network(G: nx.Graph, out_path: str | Path, title: str = '', top_labels: int = 20, seed: int = 42,
                 show_clusters: bool = True, figsize: tuple = (16, 12), dpi: int = 300) -> None:
    """
    优化版关键词共现网络图：解决节点过大、重叠糊化、标签不清问题
    
    Args:
        G: NetworkX graph.
        out_path: Output path for the PNG file.
        title: Plot title.
        top_labels: Number of top weighted-degree nodes to label (优化后默认20，更多标签).
        seed: Random seed for layout reproducibility.
        show_clusters: If True, color nodes by community.
        figsize: Figure size (width, height) in inches (优化后默认更大).
        dpi: Resolution for saved figure (优化后默认300，更高清).
    """
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    
    # 清理画布，设置高分辨率
    plt.clf()
    fig, ax = plt.subplots(figsize=figsize, dpi=dpi)
    
    # 空图处理
    if G.number_of_nodes() == 0:
        plt.title(title + ' (empty graph)')
        plt.savefig(out_path, bbox_inches='tight')
        plt.close(fig)
        return

    # ========== 1. 布局优化：调大k值让节点散开，增加迭代次数 ==========
    pos = nx.spring_layout(
        G, 
        seed=seed, 
        weight='weight', 
        k=2.5 / np.sqrt(G.number_of_nodes()),  # 原k=1.5，调大增加节点间距
        iterations=80  # 增加迭代次数，布局更稳定
    )

    # ========== 2. 节点大小归一化：压缩极值差距 ==========
    weighted_degree = dict(G.degree(weight='weight'))
    degrees = list(weighted_degree.values())
    
    # 最小-最大归一化，映射到 [80, 1800] 尺寸区间（可自行调整）
    min_deg, max_deg = min(degrees), max(degrees)
    if max_deg == min_deg:
        node_sizes = [500 for _ in G.nodes()]
    else:
        min_size, max_size = 80, 1800
        node_sizes = [
            min_size + (max_size - min_size) * (weighted_degree[n] - min_deg) / (max_deg - min_deg)
            for n in G.nodes()
        ]

    # ========== 3. 边样式优化：降低透明度，避免抢节点视线 ==========
    edge_weights = [G[u][v].get('weight', 1) for u, v in G.edges()]
    # 边宽归一化，避免过粗
    max_edge_w = max(edge_weights) if edge_weights else 1
    edge_widths = [0.3 + 2.5 * (w / max_edge_w) for w in edge_weights]
    
    nx.draw_networkx_edges(
        G, pos, 
        width=edge_widths, 
        alpha=0.15,  # 降低边透明度，突出节点
        edge_color='#95a5a6',  # 浅灰色更柔和，不抢视觉焦点
        ax=ax
    )

    # ========== 4. 节点样式优化：加边框、提高不透明度 ==========
    if show_clusters:
        node_colors = list(_get_community_colors(G).values())
    else:
        node_colors = '#3498db'
    
    nx.draw_networkx_nodes(
        G, pos, 
        node_size=node_sizes, 
        alpha=0.92,  # 提高不透明度，避免叠色糊化
        node_color=node_colors, 
        edgecolors='#2c3e50',  # 深色边框强化节点边界
        linewidths=0.8,  # 加粗边框，更清晰
        ax=ax
    )

    # ========== 5. 标签优化：自动避让、清晰可读 ==========
    # 筛选Top N个节点显示标签（按加权度排序）
    top_nodes = sorted(G.nodes(), key=lambda n: weighted_degree.get(n, 0), reverse=True)[:top_labels]
    
    texts = []
    for n in top_nodes:
        x, y = pos[n]
        # 标签长度截断（优化后支持更长标签，截断阈值30）
        label = n[:30] + '...' if len(n) > 30 else n
        texts.append(
            plt.text(
                x, y, label, 
                fontsize=9,  # 调大字体，更易读
                fontweight='semibold',
                ha='center', va='center', 
                color='#2c3e50',
                # 白色半透明背景框，保证在任何颜色节点上都清晰
                bbox=dict(
                    boxstyle="round,pad=0.3", 
                    fc="white", 
                    ec="#bdc3c7", 
                    lw=0.5, 
                    alpha=0.9
                )
            )
        )
    
    # 用adjustText自动调整标签位置，避免重叠
    try:
        from adjustText import adjust_text
        node_x = [pos[n][0] for n in G.nodes()]
        node_y = [pos[n][1] for n in G.nodes()]
        adjust_text(
            texts, 
            x=node_x, y=node_y,
            force_static=(0.3, 0.5),  # 降低避让力度，避免标签跑太远
            expand=(1.1, 1.2),        # 适度扩展避让范围
            arrowprops=dict(arrowstyle="-", color="#7f8c8d", lw=0.6, alpha=0.8)
        )
    except ImportError as e:
        print(f"Warning: adjustText not installed, falling back to standard labels: {e}")
        labels = {n: n[:30] for n in top_nodes}
        nx.draw_networkx_labels(G, pos, labels=labels, font_size=8, ax=ax)
    except Exception as e:
        print(f"Warning: adjustText failed, falling back to standard labels: {e}")
        labels = {n: n[:30] for n in top_nodes}
        nx.draw_networkx_labels(G, pos, labels=labels, font_size=8, ax=ax)

    # ========== 6. 社区图例优化（适配新样式） ==========
    if show_clusters:
        comm_map = {}
        for cid, nodes in enumerate(nx.algorithms.community.greedy_modularity_communities(G, weight='weight')):
            for n in nodes:
                comm_map[n] = cid

        unique_comms = sorted(set(comm_map.values()))
        legend_handles = []
        for c in unique_comms[:10]:  # 最多显示10个社区
            color = _CLUSTER_COLORS[c % len(_CLUSTER_COLORS)]
            size = sum(1 for v in comm_map.values() if v == c)
            legend_handles.append(
                plt.scatter([], [], c=color, s=100, label=f'Cluster {c} ({size} nodes)', 
                            edgecolors='#2c3e50', linewidths=0.8, alpha=0.92)
            )
        if legend_handles:
            plt.legend(
                handles=legend_handles, 
                loc='upper left', 
                fontsize=10,  # 调大图例字体
                framealpha=0.95, 
                title='Communities', 
                title_fontsize=11
            )

    # ========== 7. 图表样式收尾 ==========
    plt.title(title, fontsize=18, fontweight='bold', pad=20)
    plt.axis('off')
    plt.tight_layout()  # 紧凑布局，避免标签截断
    
    plt.savefig(out_path, bbox_inches='tight', dpi=dpi)
    plt.close(fig)
def draw_network_interactive(G: nx.Graph, out_path: str | Path, title: str = '', top_labels: int = 20, seed: int = 42, show_clusters: bool = True) -> None:
    """生成交互式HTML网络图，和静态draw_network配套"""
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if G.number_of_nodes() == 0:
        fig = go.Figure(layout=go.Layout(title=title + " (empty graph)"))
        fig.write_html(out_path)
        return

    # 布局计算和静态图保持一致
    pos = nx.spring_layout(
        G, seed=seed, weight='weight',
        k=2.5 / np.sqrt(G.number_of_nodes()),
        iterations=80
    )
    weighted_degree = dict(G.degree(weight='weight'))
    # 节点大小归一化
    degrees = list(weighted_degree.values())
    min_deg, max_deg = min(degrees), max(degrees)
    min_size, max_size = 8, 35
    node_sizes = []
    for n in G.nodes():
        if max_deg == min_deg:
            s = 15
        else:
            s = min_size + (max_size - min_size) * (weighted_degree[n] - min_deg) / (max_deg - min_deg)
        node_sizes.append(s)

    # 社区配色
    if show_clusters:
        comm_map = {}
        for cid, nodes in enumerate(nx.algorithms.community.greedy_modularity_communities(G, weight='weight')):
            for n in nodes:
                comm_map[n] = _CLUSTER_COLORS[cid % len(_CLUSTER_COLORS)]
        node_colors = [comm_map[n] for n in G.nodes()]
    else:
        node_colors = "#3498db"

    # 边数据
    edge_x, edge_y = [], []
    for u, v in G.edges():
        x0, y0 = pos[u]
        x1, y1 = pos[v]
        edge_x.extend([x0, x1, None])
        edge_y.extend([y0, y1, None])
    edge_trace = go.Scatter(
        x=edge_x, y=edge_y,
        line=dict(width=0.4, color="#95a5a6"),
        hoverinfo="none", mode="lines", opacity=0.2
    )

    # 节点数据
    node_x, node_y, node_text = [], [], []
    for idx, n in enumerate(G.nodes()):
        x, y = pos[n]
        node_x.append(x)
        node_y.append(y)
        text = f"<b>{n}</b><br>Weighted Degree: {weighted_degree[n]:.2f}"
        node_text.append(text)
    node_trace = go.Scatter(
        x=node_x, y=node_y,
        mode="markers",
        hovertext=node_text,
        marker=dict(
            size=node_sizes,
            color=node_colors,
            line=dict(width=0.8, color="#2c3e50"),
            opacity=0.92
        )
    )

    # 仅Top节点显示文本标签
    top_nodes = sorted(G.nodes(), key=lambda n: weighted_degree[n], reverse=True)[:top_labels]
    label_x, label_y, label_text = [], [], []
    for n in top_nodes:
        x, y = pos[n]
        label_x.append(x)
        label_y.append(y)
        label_text.append(n[:30])
    label_trace = go.Scatter(
        x=label_x, y=label_y,
        text=label_text,
        mode="text",
        textfont=dict(size=9, weight="bold", color="#2c3e50"),
        hoverinfo="none"
    )

    fig = go.Figure(data=[edge_trace, node_trace, label_trace],
                    layout=go.Layout(
                        title=dict(text=title, font_size=18),
                        showlegend=False,
                        xaxis=dict(visible=False),
                        yaxis=dict(visible=False),
                        paper_bgcolor="white",
                        plot_bgcolor="white",
                        width=1600, height=1200
                    ))
    fig.write_html(out_path)
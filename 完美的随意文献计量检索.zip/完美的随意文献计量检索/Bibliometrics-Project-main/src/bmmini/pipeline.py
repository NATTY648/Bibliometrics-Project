from __future__ import annotations
import argparse
import os
from pathlib import Path
from datetime import datetime
import pandas as pd

from .utils import load_config, ensure_dirs, read_jsonl, load_invalid_keywords_from_file
from .normalize import save_normalized
from .parse_wos import parse_wos_dir, save_normalized_wos
from .fetch_openalex import fetch_openalex_works
from .matrices import (
    bibliographic_coupling_edges,
    co_citation_edges,
    keyword_cooccurrence_edges,
    coauthorship_edges,
)
from .metrics import graph_from_edges, node_metrics, network_summary, descriptive_indicators, cluster_summary
from .visualize import draw_network, draw_network_interactive


def run_pipeline(config: dict, use_sample: bool = False, use_wos: bool = False, fetch_openalex: bool = False) -> None:
    ensure_dirs(config)
    processed_dir = Path(config['outputs']['processed_dir'])
    tables_dir = Path(config['outputs']['tables_dir'])
    figures_dir = Path(config['outputs']['figures_dir'])
    reports_dir = Path(config['outputs']['reports_dir'])

    # ========== 全局统一加载无效关键词配置 ==========
    invalid_kw_file = Path(config.get('data', {}).get('invalid_keywords_file', 'config/invalid_keywords.txt'))
    min_kw_length = config['data'].get('min_keyword_length', 2)
    
    try:
        custom_invalid_keys = load_invalid_keywords_from_file(invalid_kw_file)
        print(f"已加载全局无效关键词 {len(custom_invalid_keys)} 个，来自: {invalid_kw_file.absolute()}")
    except FileNotFoundError:
        custom_invalid_keys = None
        print(f"全局停用词文件 {invalid_kw_file.absolute()} 不存在，使用默认过滤规则")
    # ==============================================

    # 分支1：在线拉取 OpenAlex 文献数据
    if fetch_openalex:
        print("\n=== 开始从OpenAlex API在线检索文献 ===")
        works_raw = fetch_openalex_works(config)
        raw_count = len(works_raw)  # 清洗前数量
        raw_path = Path(config['data']['raw_jsonl'])
        print(f"OpenAlex下载完成，共 {raw_count} 篇文献保存至 {raw_path}")
        records = works_raw
        # 统一传参：全局停用词 + 最小长度
# 以OpenAlex分支为例（其他分支同理）
        paths = save_normalized(
            records, 
            config['outputs']['processed_dir'],
            invalid_keywords=custom_invalid_keys,
            min_keyword_length=min_kw_length,
            from_year=config['data'].get('from_year'),  # 从配置读取年份范围
            to_year=config['data'].get('to_year'),
            require_keywords=config['analysis'].get('require_keywords', True),  # 配置是否要求关键词
            require_authors=config['analysis'].get('require_authors', True)    # 配置是否要求作者
        )
        # 统计清洗后数量并打印汇报
        cleaned_works = pd.read_csv(paths['works'])
        cleaned_count = len(cleaned_works)
        removed_count = raw_count - cleaned_count
        print("="*50)
        print("📊 文献数据清洗统计（OpenAlex来源）")
        print(f"清洗前文献数量：{raw_count} 篇")
        print(f"清洗掉文献数量：{removed_count} 篇")
        print(f"清洗后文献数量：{cleaned_count} 篇")
        print("="*50)
        is_openalex_source = True

    # 分支2：本地WOS导出文本数据
    elif use_wos:
        wos_dir = config['data'].get('wos_dir', 'data/sample-wos')
        records = parse_wos_dir(wos_dir)
        raw_count = len(records)  # 清洗前数量
        # 统一传参：全局停用词 + 最小长度
        paths = save_normalized_wos(
            records, 
            config['outputs']['processed_dir'],
            invalid_keywords=custom_invalid_keys,
            min_keyword_length=min_kw_length,
            from_year=config['data'].get('from_year'),  # 从配置读取年份范围
            to_year=config['data'].get('to_year'),
            require_keywords=config['analysis'].get('require_keywords', True),  # 配置是否要求关键词
            require_authors=config['analysis'].get('require_authors', True)    # 配置是否要求作者
        )
        # 统计清洗后数量并打印汇报
        cleaned_works = pd.read_csv(paths['works'])
        cleaned_count = len(cleaned_works)
        removed_count = raw_count - cleaned_count
        print("="*50)
        print("📊 文献数据清洗统计（WOS来源）")
        print(f"清洗前文献数量：{raw_count} 篇")
        print(f"清洗掉文献数量：{removed_count} 篇")
        print(f"清洗后文献数量：{cleaned_count} 篇")
        print("="*50)
        raw_path = wos_dir
        is_openalex_source = False

    # 分支3：本地JSONL文件（样本/自定义离线数据）
    else:
        raw_path = Path(config['data']['sample_jsonl'] if use_sample else config['data']['raw_jsonl'])
        records = read_jsonl(raw_path)
        raw_count = len(records)  # 清洗前数量
        # 统一传参：全局停用词 + 最小长度
    # 以OpenAlex分支为例（其他分支同理）
        paths = save_normalized(
            records, 
            config['outputs']['processed_dir'],
            invalid_keywords=custom_invalid_keys,
            min_keyword_length=min_kw_length,
            from_year=config['data'].get('from_year'),  # 从配置读取年份范围
            to_year=config['data'].get('to_year'),
            require_keywords=config['analysis'].get('require_keywords', True),  # 配置是否要求关键词
            require_authors=config['analysis'].get('require_authors', True)    # 配置是否要求作者
        )
        # 统计清洗后数量并打印汇报
        cleaned_works = pd.read_csv(paths['works'])
        cleaned_count = len(cleaned_works)
        removed_count = raw_count - cleaned_count
        print("="*50)
        print("📊 文献数据清洗统计（本地JSONL来源）")
        print(f"清洗前文献数量：{raw_count} 篇")
        print(f"清洗掉文献数量：{removed_count} 篇")
        print(f"清洗后文献数量：{cleaned_count} 篇")
        print("="*50)
        is_openalex_source = False

    works = pd.read_csv(paths['works'])
    refs = pd.read_csv(paths['references'])
    authors = pd.read_csv(paths['authors'])
    keywords = pd.read_csv(paths['keywords'])

    min_w = config['analysis'].get('min_edge_weight', 1)
    top_edges = config['analysis'].get('top_edges', 200)
    seed = config['analysis'].get('layout_seed', 42)
    top_labels = config['analysis'].get('top_labels', 12)

    edge_tables = {
        'keyword_cooccurrence': keyword_cooccurrence_edges(keywords, min_weight=min_w, top_edges=top_edges),
        'co_citation': co_citation_edges(refs, min_weight=min_w, top_edges=top_edges),
        'bibliographic_coupling': bibliographic_coupling_edges(refs, min_weight=min_w, top_edges=top_edges),
        'coauthorship': coauthorship_edges(authors, min_weight=min_w, top_edges=top_edges),
    }

    summaries = []
    network_results = {}
    for name, edges in edge_tables.items():
        edge_path = tables_dir / f'{name}_edges.csv'
        edges.to_csv(edge_path, index=False)

        G = graph_from_edges(edges)
        metrics = node_metrics(G)
        metrics.to_csv(tables_dir / f'network_metrics_{name}.csv', index=False)

        csum = cluster_summary(metrics)
        if not csum.empty:
            csum.to_csv(tables_dir / f'cluster_summary_{name}.csv', index=False)

        summary = network_summary(G)
        summary['network'] = name
        summaries.append(summary)

        title_display = name.replace('_', ' ').title()
        draw_network(G, figures_dir / f'{name}_network.png', title=title_display, top_labels=top_labels, seed=seed)
        draw_network_interactive(
            G, figures_dir / f'{name}_network.html',
            title=title_display, seed=seed   # 删除 metrics_df=metrics
        )

        network_results[name] = {
            'graph': G,
            'edges': edges,
            'metrics': metrics,
            'cluster_summary': csum,
            'summary': summary,
        }

    pd.DataFrame(summaries).to_csv(tables_dir / 'network_qc_summary.csv', index=False)
    desc_indicators = descriptive_indicators(works, authors)
    desc_indicators.to_csv(tables_dir / 'descriptive_indicators.csv', index=False)

    _generate_html_report(
        reports_dir=reports_dir,
        tables_dir=tables_dir,
        figures_dir=figures_dir,
        network_results=network_results,
        desc_indicators=desc_indicators,
        raw_data_source=str(raw_path),
        n_works=len(works), n_refs=len(refs), n_authors=len(authors), n_keywords=len(keywords),
        seed=seed, top_edges=top_edges, min_edge_weight=min_w,   # 改为 min_w
        is_openalex=is_openalex_source,
        invalid_kw_file=invalid_kw_file,
        min_kw_length=min_kw_length    # 新增这一行（如果函数定义中已接收）
    )

    # 输出方法说明Markdown
    with open(reports_dir / 'method_note.md', 'w', encoding='utf-8') as f:
        f.write('# Method note\n\n')
        if is_openalex_source:
            f.write(f"Raw data source: OpenAlex REST API\nSearch filter: {config['data']['query']}, year range {config['data']['from_year']}-{config['data']['to_year']}\nLocal cache file: `{raw_path}`\n\n")
        else:
            f.write(f"Raw data: `{raw_path}`\n\n")
        f.write(f"Seed works: {len(works)}; reference pairs: {len(refs)}; authorship rows: {len(authors)}; keyword rows: {len(keywords)}.\n\n")
        f.write('Matrices: keyword W=K.T@K; co-citation C=A.T@A; bibliographic coupling B=A@A.T.\n')
        f.write('Betweenness centrality uses distance=1/weight for similarity networks.\n')

    print('Pipeline finished. See outputs/tables, outputs/figures, and reports.')


def _df_to_html_table(df: pd.DataFrame, caption: str = '', max_rows: int = 50) -> str:
    """Convert a DataFrame to a styled HTML table string."""
    if df is None or df.empty:
        return f'<p class="text-muted">No data available for <b>{caption}</b>.</p>'
    display_df = df.head(max_rows).copy()
    display_df = display_df.map(lambda x: round(x, 4) if isinstance(x, float) else x)
    html = display_df.to_html(classes='table table-striped table-hover table-sm table-bordered', index=False, escape=False)
    if caption:
        html = f'<h5>{caption}</h5>\n{html}'
    return html


def _generate_html_report(reports_dir: Path, tables_dir: Path, figures_dir: Path,
                           network_results: dict, desc_indicators: pd.DataFrame,
                           raw_data_source: str, n_works: int, n_refs: int,
                           n_authors: int, n_keywords: int,
                           seed: int, top_edges: int, min_edge_weight: int,
                           is_openalex: bool = False,
                           invalid_kw_file: Path = None,
                           min_kw_length: int = 2) -> None:   # ← 新增参数
    """Generate a comprehensive HTML report embedding all figures and tables."""
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    fig_rel_base = Path(os.path.relpath(figures_dir.resolve(), reports_dir.resolve()))
    network_sections = []

    net_names_order = ['keyword_cooccurrence', 'co_citation', 'bibliographic_coupling', 'coauthorship']
    net_titles = {
        'keyword_cooccurrence': 'Keyword Co-occurrence Network (W = K.T @ K)',
        'co_citation': 'Co-citation Network (C = A.T @ A)',
        'bibliographic_coupling': 'Bibliographic Coupling Network (B = A @ A.T)',
        'coauthorship': 'Co-authorship Collaboration Network',
    }

    source_label = "OpenAlex API Online Fetch" if is_openalex else raw_data_source

    for name in net_names_order:
        if name not in network_results:
            continue
        res = network_results[name]
        s = res['summary']
        m = res['metrics']
        cs = res.get('cluster_summary', pd.DataFrame())
        title = net_titles.get(name, name.replace('_', ' ').title())
        png_rel = figures_dir / f'{name}_network.png'
        html_rel = figures_dir / f'{name}_network.html'
        png_href = fig_rel_base / png_rel.name
        html_href = fig_rel_base / html_rel.name

        section_parts = [
            f'<div id="section-{name}" class="network-section mb-5">',
            f'<h3 class="mt-4 mb-3">{title}</h3>',
        ]

        section_parts.append('<div class="row"><div class="col-md-6">')
        section_parts.append(f'<h5>Network Overview</h5>')
        overview_items = [
            ('Nodes', s.get('n_nodes', '-')),
            ('Edges', s.get('n_edges', '-')),
            ('Density', f"{s.get('density', 0):.4f}"),
            ('Communities', s.get('n_communities', '-')),
            ('Modularity', f"{s.get('modularity', 0):.4f}"),
            ('Avg Clustering Coefficient', f"{s.get('avg_clustering_coefficient', 0):.4f}"),
            ('Avg Degree', f"{s.get('avg_degree', 0):.2f}"),
            ('Avg Weighted Degree', f"{s.get('avg_weighted_degree', 0):.2f}"),
            ('Components', s.get('n_components', '-')),
            ('Largest Component Ratio', f"{s.get('largest_component_ratio', 0):.2%}" if isinstance(s.get('largest_component_ratio'), float) else str(s.get('largest_component_ratio', '-'))),
        ]
        if s.get('diameter_largest_component', 0) > 0:
            overview_items.append(('Diameter (Largest CC)', s['diameter_largest_component']))
        if s.get('avg_path_length_largest_component', 0) > 0:
            overview_items.append(('Avg Path Length (Largest CC)', f"{s.get('avg_path_length_largest_component', 0):.3f}"))

        section_parts.append('<table class="table table-sm table-bordered">')
        section_parts.append('<tbody>')
        for label, val in overview_items:
            section_parts.append(f'<tr><th style="width:45%">{label}</th><td>{val}</td></tr>')
        section_parts.append('</tbody></table>')
        section_parts.append('</div><div class="col-md-6">')
        section_parts.append(f'<h5>Static Network Map</h5>')
        if png_rel.exists():
            section_parts.append(f'<a href="{png_href}" target="_blank"><img src="{png_href}" class="img-fluid rounded border shadow-sm" alt="{title}" style="max-width:100%;"></a>')
            section_parts.append(f'<p class="small text-muted mt-1">Click to enlarge. Nodes colored by community/cluster.</p>')
        else:
            section_parts.append('<p class="text-muted">Image not available.</p>')
        section_parts.append('</div></div>')

        section_parts.append(f'<hr class="my-3"><h5>Interactive Network Map</h5>')
        section_parts.append(f'<iframe src="{html_href}" width="100%" height="600" frameborder="0" class="border rounded shadow-sm" allowfullscreen></iframe>')
        section_parts.append(f'<p class="small text-muted mt-1">Hover over nodes to see detailed metrics. Drag nodes to reposition. Scroll to zoom.</p>')

        section_parts.append(f'<hr class="my-3"><h5>Top-20 Node Metrics</h5>')
        m_top = m.head(20)[['node','degree','weighted_degree','betweenness','pagerank','closeness','community']].copy()
        m_top = m_top.map(lambda x: round(x, 4) if isinstance(x, float) else x)
        m_top.columns = ['Node', 'Degree', 'Weighted Deg.', 'Betweenness', 'PageRank', 'Closeness', 'Cluster']
        section_parts.append(m_top.to_html(classes='table table-striped table-hover table-sm table-bordered', index=False))

        if cs is not None and not cs.empty:
            section_parts.append(f'<hr class="my-3"><h5>Cluster / Community Summary</h5>')
            cs_disp = cs.copy()
            cs_disp = cs_disp.map(lambda x: round(x, 4) if isinstance(x, float) else x)
            cs_disp.columns = [c.replace('_', ' ').title() for c in cs_disp.columns]
            section_parts.append(cs_disp.to_html(classes='table table-striped table-hover table-sm table-bordered', index=False))

        section_parts.append('</div>')
        network_sections.append('\n'.join(section_parts))

    desc_items = []
    if not desc_indicators.empty:
        row = desc_indicators.iloc[0]
        labels_map = {
            'n_works': 'Total Seed Works',
            'year_min': 'Earliest Year',
            'year_max': 'Latest Year',
            'total_citations': 'Total Citations',
            'mean_citations': 'Mean Citations per Work',
            'h_index_seed_works': 'H-index (Seed Works)',
            'n_authors': 'Unique Authors',
        }
        for col, lbl in labels_map.items():
            val = row.get(col)
            if val is None:
                continue
            if isinstance(val, float):
                desc_items.append((lbl, f'{val:.2f}'))
            else:
                desc_items.append((lbl, str(val)))

    html_content = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bibliometrics Report - {now.split()[0]}</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background-color: #f8f9fa; }}
.report-header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 2rem 0; margin-bottom: 2rem; }}
.report-header h1 {{ margin-bottom: 0.3rem; }}
.network-section {{ background: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }}
.table {{ font-size: 0.9rem; }}
.table th {{ background-color: #f1f3f5; position: sticky; top: 0; }}
.badge-cluster {{ font-size: 0.75em; }}
.toc-nav {{ position: sticky; top: 1rem; }}
@media print {{ .no-print {{ display: none !important; }} iframe {{ display: none; }} img {{ max-width: 100%; page-break-inside: avoid; }} .network-section {{ break-inside: avoid; }} }}
</style>
</head>
<body>
<div class="report-header">
<div class="container">
<h1>Bibliometrics Analysis Report</h1>
<p class="mb-0 opacity-75">Generated on {now} | Data source: <code>{source_label}</code></p>
</div>
</div>
<div class="container">
<nav aria-label="breadcrumb" class="mb-3 no-print">
<ol class="breadcrumb">
<li class="breadcrumb-item active">Report Home</li>
</ol>
</nav>
<div class="row">
<div class="col-lg-3 no-print">
<div class="card sticky-top toc-nav" style="top:1rem;">
<div class="card-header bg-light fw-bold">Table of Contents</div>
<ul class="list-group list-group-flush">
<li class="list-group-item list-group-item-action"><a href="#overview">Overview</a></li>
'''
    for name in net_names_order:
        if name in network_results:
            html_content += f'<li class="list-group-item list-group-item-action"><a href="#section-{name}">{net_titles.get(name, name)}</a></li>\n'
    
    html_content += '''</ul></div></div>
<div class="col-lg-9">
<section id="overview" class="network-section mb-4">
<h3>Data Overview & Descriptive Indicators</h3>
<div class="row">
<div class="col-md-6">
<table class="table table-sm table-bordered">
<tbody>
<tr><th>Seed Works</th><td>{n_works:,}</td></tr>
<tr><th>Reference Pairs</th><td>{n_refs:,}</td></tr>
<tr><th>Authorship Rows</th><td>{n_authors:,}</td></tr>
<tr><th>Keyword Rows</th><td>{n_keywords:,}</td></tr>
</tbody>
</table>
</div>
<div class="col-md-6">
<table class="table table-sm table-bordered">
<tbody>
'''.format(n_works=n_works, n_refs=n_refs, n_authors=n_authors, n_keywords=n_keywords)
    
    for i, (label, value) in enumerate(desc_items):
        html_content += f'<tr><th>{label}</th><td>{value}</td></tr>\n'
    
    html_content += '''</tbody></table></div></div>
<hr>
<p><strong>Analysis Parameters:</strong> layout_seed={seed}, top_edges={top_edges}, min_edge_weight={min_edge_weight}</p>
<p><strong>Keyword Filter:</strong> min length={min_kw_length}, invalid keywords from {invalid_kw_file}</p>
<p><strong>Formulas:</strong> Keyword co-occurrence W = K.T @ K | Co-citation C = A.T @ A | Bibliographic coupling B = A @ A.T<br>
Betweenness centrality uses distance = 1/weight for similarity-weighted networks.</p>
</section>
'''
    html_content += '\n'.join(network_sections)
    html_content += f'''
</div>
</div>
<footer class="text-center text-muted py-4 mt-5 border-top no-print">
<small>Bibliometrics-mini Pipeline Report | Generated automatically | Keyword filter: {invalid_kw_file.name}</small>
</footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
'''
        # ---- 自动转义 CSS/JS 中的花括号，保留合法占位符 ----
    import re
    # 1. 提取所有合法占位符（由字母、数字、下划线组成，允许空格和标点？不，严格匹配变量名）
    placeholders = set(re.findall(r'\{[a-zA-Z_][a-zA-Z0-9_]*\}', html_content))
    # 2. 用唯一标记替换占位符
    marker_map = {}
    for i, ph in enumerate(placeholders):
        marker = f'###PH{i}###'
        marker_map[marker] = ph
        html_content = html_content.replace(ph, marker)
    # 3. 将剩余所有花括号转义（CSS/JS 部分）
    html_content = html_content.replace('{', '{{').replace('}', '}}')
    # 4. 恢复占位符
    for marker, ph in marker_map.items():
        html_content = html_content.replace(marker, ph)
    # ------------------------------------------------
    # 填充模板变量
    html_content = html_content.format(
        seed=seed, 
        top_edges=top_edges, 
        min_edge_weight=min_edge_weight,
        min_kw_length=min_kw_length,
        invalid_kw_file=invalid_kw_file.name
    )
    
    report_path = reports_dir / 'bibliometrics_report.html'
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(html_content)


def main() -> None:
    parser = argparse.ArgumentParser(description="文献计量全流程工具：支持OpenAlex在线检索 / WOS本地文件 / 离线JSONL")
    parser.add_argument('--config', default='config/query.yaml', help="配置文件路径，默认 config/query.yaml")
    parser.add_argument('--use-sample', action='store_true', help="使用内置样本数据运行")
    parser.add_argument('--use-wos', action='store_true', help="读取本地WOS导出txt数据集")
    parser.add_argument('--fetch-openalex', action='store_true', help="【线上模式】从OpenAlex API在线下载文献再分析")
    args = parser.parse_args()

    run_pipeline(
        load_config(args.config),
        use_sample=args.use_sample,
        use_wos=args.use_wos,
        fetch_openalex=args.fetch_openalex
    )


if __name__ == '__main__':
    main()
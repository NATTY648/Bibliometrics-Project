import requests
import time
import argparse
from tqdm import tqdm
from pathlib import Path
from dotenv import load_dotenv
import os

# 复用项目工具函数（包内相对导入）
from .utils import load_config, write_jsonl

# 加载环境变量，读取OpenAlex API密钥
load_dotenv()

# ====== 修改后 ======
def fetch_openalex_works(config: str | Path | dict = "config.yaml") -> list[dict]:
    """
    从 OpenAlex API 抓取文献元数据，保存为 JSONL 格式。
    完全适配配置文件中的检索参数、分页参数与输出路径。
    ✅ 支持两种入参：配置文件路径 / 已加载的配置字典
    返回抓取到的文献列表，供上层流水线调用。
    """
    # 1. 加载配置：兼容路径字符串和已解析的字典
    if not isinstance(config, dict):
        config = load_config(config)
    
    data_cfg = config["data"]
    
    # 基础参数校验
    if data_cfg["source"].lower() != "openalex":
        raise ValueError(f"配置中数据源为 {data_cfg['source']}，本脚本仅支持 openalex")
    
    # 读取API密钥
    openalex_api_key = os.getenv("OPENALEX_API_KEY")
    
    # 2. 构造 API 请求基础参数
    base_url = "https://api.openalex.org/works"
    params = {
        "search": data_cfg["query"],
        "filter": (
            f"type:{data_cfg['type']},"
            f"publication_year:{data_cfg['from_year']}-{data_cfg['to_year']}"
        ),
        "per_page": data_cfg["per_page"],
        "page": 1,
        # 填入你的邮箱可进入OpenAlex礼貌池，请求更稳定、速率限制更宽松
        "mailto": "your-email@example.com",
    }
    
    # 加入API密钥
    if openalex_api_key:
        params["api_key"] = openalex_api_key
    
    max_records = data_cfg["max_records"]
    all_works = []
    max_retries = 3  # 单页请求最大重试次数
    
    # 3. 预请求获取总结果数
    print(f"正在连接 OpenAlex API，检索关键词：{data_cfg['query']}")
    response = requests.get(base_url, params=params, timeout=30)
    response.raise_for_status()
    meta = response.json()["meta"]
    total_available = meta["count"]
    print(f"OpenAlex 中匹配文献总数：{total_available} 条")
    print(f"配置最大抓取量：{max_records} 条，单页 {data_cfg['per_page']} 条")
    
    # 计算实际需要抓取的页数
    total_target = min(total_available, max_records)
    total_pages = (total_target + data_cfg["per_page"] - 1) // data_cfg["per_page"]
    
    # OpenAlex 分页限制校验：page 模式最多仅支持前 10000 条
    if total_target > 10000:
        raise ValueError(
            "OpenAlex 普通分页仅支持前 10000 条记录，"
            "若需抓取更多数据请使用 Cursor 分页模式"
        )
    
    # 4. 分页循环抓取
    with tqdm(total=total_target, desc="抓取进度") as pbar:
        for page in range(1, total_pages + 1):
            params["page"] = page
            
            # 带重试的请求逻辑
            for attempt in range(max_retries):
                try:
                    resp = requests.get(base_url, params=params, timeout=30)
                    resp.raise_for_status()
                    page_data = resp.json()
                    break
                except requests.exceptions.RequestException as e:
                    if attempt == max_retries - 1:
                        raise RuntimeError(f"第 {page} 页抓取失败，已重试 {max_retries} 次：{e}")
                    wait_time = 2 ** attempt
                    print(f"\n第 {page} 页请求失败（第 {attempt+1} 次），{wait_time}s 后重试...")
                    time.sleep(wait_time)
            
            works = page_data["results"]
            
            # 最后一页截断，避免超出 max_records
            remaining = max_records - len(all_works)
            if len(works) > remaining:
                works = works[:remaining]
            
            all_works.extend(works)
            pbar.update(len(works))
            
            # 请求间隔，避免触发速率限制
            time.sleep(0.1)
            
            # 达到最大数量提前终止
            if len(all_works) >= max_records:
                break
    
    # 5. 写入 JSONL 文件（复用 utils 中的写入函数）
    output_path = Path(data_cfg["raw_jsonl"])
    write_jsonl(output_path, all_works)
    
    print(f"\n抓取完成！共获取 {len(all_works)} 条文献数据")
    print(f"数据已保存至：{output_path.resolve()}")
    
    # 返回文献列表，供上层流水线使用
    return all_works

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="OpenAlex 文献数据抓取脚本")
    parser.add_argument(
        "--config", 
        default="config/query.yaml", 
        help="YAML 配置文件路径，默认读取当前目录下的 config/query.yaml"
    )
    args = parser.parse_args()
    fetch_openalex_works(args.config)
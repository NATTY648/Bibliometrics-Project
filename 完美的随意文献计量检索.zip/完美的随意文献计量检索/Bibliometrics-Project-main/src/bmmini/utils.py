from __future__ import annotations

from pathlib import Path
import json
import yaml
import re
import unicodedata
from typing import Optional


def load_config(path: str | Path) -> dict:
    """Load a YAML configuration file."""
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def ensure_dirs(config: dict) -> None:
    """Create standard output directories defined in the config."""
    for key in ['processed_dir', 'tables_dir', 'figures_dir', 'reports_dir']:
        Path(config['outputs'][key]).mkdir(parents=True, exist_ok=True)


def read_jsonl(path: str | Path) -> list[dict]:
    """Read a JSONL file into a list of dictionaries."""
    rows = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def write_jsonl(path: str | Path, rows: list[dict]) -> None:
    """Write dictionaries as JSONL."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + '\n')


def _clean_text(text: str | None) -> str:
    """全局统一文本清洗（WOS/OpenAlex共用）"""
    if not text:
        return ''
    # 转为字符串并标准化unicode（处理全角/半角）
    text = unicodedata.normalize('NFKC', str(text))
    # 移除非打印字符（保留换行/制表符外的可见字符）
    text = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', text)
    # 替换所有空白符为单个空格
    text = re.sub(r'\s+', ' ', text)
    # 移除首尾标点和空格
    text = re.sub(r'^[\s\W]+|[\s\W]+$', '', text)
    # 过滤纯数字/纯标点的无意义文本
    if re.match(r'^[\d\W]+$', text):
        return ''
    return text.strip()


def load_invalid_keywords_from_file(file_path, encoding="utf-8"):
    fp = Path(file_path)
    if not fp.exists():
        raise FileNotFoundError(f"停用词文件不存在: {fp}")
    invalid = set()
    with open(fp, "r", encoding=encoding) as f:
        for line in f:
            stripped = line.strip()
            # 先跳过空行和注释行（#开头的行）
            if not stripped or stripped.startswith("#"):
                continue
            # 再清洗
            cleaned = _clean_text(stripped)
            if cleaned:  # 非空才加入
                invalid.add(cleaned.lower())
    return frozenset(invalid)


def filter_single_keyword(
    kw: str, 
    invalid_set: frozenset[str], 
    min_len: int
) -> Optional[str]:
    """统一关键词过滤函数，两套数据源通用"""
    clean_kw = _clean_text(kw).lower()
    if not clean_kw:
        return None
    if len(clean_kw) < min_len:
        return None
    if clean_kw in invalid_set:
        return None
    return clean_kw
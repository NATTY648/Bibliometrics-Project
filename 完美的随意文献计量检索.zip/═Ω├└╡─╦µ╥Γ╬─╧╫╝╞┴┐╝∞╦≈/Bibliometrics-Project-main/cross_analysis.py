import json
import pandas as pd
from pathlib import Path
from collections import Counter

# ===================== 1. 读取两个数据集 =====================
def read_jsonl(path):
    records = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records

# 读取两个数据集
pet_records = read_jsonl('data/raw/pet_group.jsonl')
nano_records = read_jsonl('data/raw/nano_group.jsonl')

# 用OpenAlex唯一ID匹配交集
pet_ids = {r['id'] for r in pet_records}
nano_ids = {r['id'] for r in nano_records}
cross_ids = pet_ids & nano_ids

# 提取交叉文献完整信息
cross_records = [r for r in pet_records if r['id'] in cross_ids]

# 输出基础统计
print("="*50)
print("双数据集基础统计")
print(f"PET组文献总数：{len(pet_records)}")
print(f"纳米传感组文献总数：{len(nano_records)}")
print(f"交叉文献数量：{len(cross_records)}")
print(f"交叉占比（相对PET组）：{len(cross_records)/len(pet_records)*100:.2f}%")
print(f"交叉占比（相对纳米组）：{len(cross_records)/len(nano_records)*100:.2f}%")
print("="*50)

# ===================== 2. 交叉文献逐年分布 =====================
year_counts = Counter()
for r in cross_records:
    year = r.get('publication_year', 0)
    if year:
        year_counts[year] += 1

year_df = pd.DataFrame(sorted(year_counts.items()), columns=['年份', '发文量'])
year_df['当年占比(%)'] = (year_df['发文量'] / year_df['发文量'].sum() * 100).round(2)

# ===================== 3. 交叉文献关键词统计 =====================
all_keywords = []
for r in cross_records:
    # 提取作者关键词和主题词
    for kw in r.get('keywords', []):
        name = kw.get('display_name', '').lower().strip()
        if name:
            all_keywords.append(name)
    for topic in r.get('topics', []):
        name = topic.get('display_name', '').lower().strip()
        if name:
            all_keywords.append(name)

kw_counter = Counter(all_keywords)
top_kw = pd.DataFrame(kw_counter.most_common(30), columns=['关键词', '出现频次'])

# ===================== 4. 交叉文献高被引Top10 =====================
sorted_cross = sorted(cross_records, key=lambda x: x.get('cited_by_count', 0), reverse=True)
top_cited = []
for r in sorted_cross[:10]:
    authors = ', '.join([a['author']['display_name'] for a in r.get('authorships', [])[:3]])
    top_cited.append({
        '标题': r.get('display_name', ''),
        '第一作者': authors,
        '发表年份': r.get('publication_year', ''),
        '期刊': r.get('primary_location', {}).get('source', {}).get('display_name', ''),
        '被引次数': r.get('cited_by_count', 0),
        'DOI': r.get('doi', '')
    })
top_cited_df = pd.DataFrame(top_cited)

# ===================== 5. 保存所有结果 =====================
output_dir = Path('reports/cross_analysis')
output_dir.mkdir(parents=True, exist_ok=True)

year_df.to_csv(output_dir / '交叉文献逐年分布.csv', index=False, encoding='utf-8-sig')
top_kw.to_csv(output_dir / '交叉文献Top30关键词.csv', index=False, encoding='utf-8-sig')
top_cited_df.to_csv(output_dir / '交叉文献高被引Top10.csv', index=False, encoding='utf-8-sig')

# 保存交叉文献完整原始数据
with open(output_dir / '交叉文献完整列表.jsonl', 'w', encoding='utf-8') as f:
    for r in cross_records:
        f.write(json.dumps(r, ensure_ascii=False) + '\n')

print("\n✅ 交叉分析完成，所有结果已保存到 reports/cross_analysis/")
print("\n交叉文献逐年分布：")
print(year_df)
print("\n交叉文献Top10关键词：")
print(top_kw.head(10))